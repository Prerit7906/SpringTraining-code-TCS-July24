package com.tcs.waleed.development;

public class AnnonymousVersion2 {
	public static void main(String[] args) {
		
//		I want to call SomeOther's doSomething:
		SomeOther other = new SomeOther();
		other.doSomething(new Building() {
			@Override
			public void work() {
				System.out.println("Remarkable this...");
				
			}
		});
		
	}
}



interface Building{
	void work();
}

class SomeOther{
	void doSomething(Building building) {
		building.work();
	}
}



