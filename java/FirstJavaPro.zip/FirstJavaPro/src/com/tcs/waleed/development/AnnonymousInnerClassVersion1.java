package com.tcs.waleed.development;

public class AnnonymousInnerClassVersion1 {
	public static void main(String[] args) {
		
//		Requirement of calling Remote's workFromHome:
		Remote remote = new Remote() {
			@Override
			public void workFromHome() {
				System.out.println("Magical this...");
			}
		};
		remote.workFromHome();
		
	}
}

interface Remote{
	void workFromHome();
}