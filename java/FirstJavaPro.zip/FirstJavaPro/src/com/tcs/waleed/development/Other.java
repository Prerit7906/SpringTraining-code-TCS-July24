package com.tcs.waleed.development;

public class Other {
	protected void doIt() {
		System.out.println("Inside doIt...");
	}

}
