package com.tcs.waleed.development;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		Set<Integer> set = new TreeSet<>();
		
		set.add(345);
		set.add(11);
		set.add(2222);
		set.add(339);
		
		System.out.println(set);
	
	}
}
