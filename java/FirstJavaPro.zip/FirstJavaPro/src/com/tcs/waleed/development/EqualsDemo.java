package com.tcs.waleed.development;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class EqualsDemo {
	
	public static void main(String[] args) {
		
		Phone phone = new Phone(6, "galaxys23", "Samsung");
		Phone otherPhone = new Phone(12, "i78", "Sony");
		
		ArrayList<Phone> listOfPhones = new ArrayList<>();
		
		listOfPhones.add(phone);
		listOfPhones.add(otherPhone);
		listOfPhones.add(new Phone(8, "12pro", "Apple"));
		
//		Collections.sort(listOfPhones, new SortByName());
		listOfPhones.sort(new SortByManufacturer());//Java 8's list.sort
		
		System.out.println(listOfPhones);
		
//		listOfNames.add("TCS");
//		listOfNames.add("IBM");
//		listOfNames.add("Infosys");
//		listOfNames.add("JpmChase");
//		
////		Sort
//		Collections.sort(listOfNames);
//		
//		System.out.println(listOfNames);
//		
		
		
		
		
//		if(phone.equals(otherPhone)) {
//			System.out.println("Same phones");
//		}
//		else {
//			System.out.println("Different phones");
//		}
		
	}

}

//Starting with Java 17:
//record Phone(Integer ram, String name, String manufacturer) {}

class Phone{ //implements Comparable<Phone>{
	private Integer ram;
	private String name;
	private String manufacturer;
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Phone)
			return this.getManufacturer().equals(((Phone)obj).getManufacturer());
		return false;
	}
	
	
	
	public Phone(Integer ram, String name, String manufacturer) {
		super();
		this.ram = ram;
		this.name = name;
		this.manufacturer = manufacturer;
	}


	public Phone() {
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "Phone [ram=" + ram + ", name=" + name + ", manufacturer=" + manufacturer + "]";
	}


	public Integer getRam() {
		return ram;
	}
	public void setRam(Integer ram) {
		this.ram = ram;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}



//	@Override
//	public int compareTo(Phone o) {
//		
//		return this.getManufacturer().compareTo(o.getManufacturer());
//	}
}

//Comparator
//	- compare(ref1, ref2)

class SortByRam implements Comparator<Phone>{

	@Override
	public int compare(Phone firstPhone, Phone secondPhone) {
		return firstPhone.getRam().compareTo(secondPhone.getRam());
	}
	
}

class SortByName implements Comparator<Phone>{

	@Override
	public int compare(Phone firstPhone, Phone secondPhone) {
		return firstPhone.getName().compareTo(secondPhone.getName());
	}
	
}

class SortByManufacturer implements Comparator<Phone>{

	@Override
	public int compare(Phone firstPhone, Phone secondPhone) {
		return firstPhone.getManufacturer().compareTo(secondPhone.getManufacturer());
	}
	
}













	
