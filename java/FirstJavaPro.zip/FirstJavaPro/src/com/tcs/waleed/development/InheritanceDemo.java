package com.tcs.waleed.development;

interface First{
	default void met() {
		System.out.println("First's met...");
	}
}

interface Second{
	void met();
}

class Sub implements First, Second{
	@Override
	public void met() {
		//Works
	}
}



public class InheritanceDemo {
	public static void main(String[] args) {
//		Human human = new Human();
//		
//		human.breathe();
//		human.sleep();
		
//		Vivek vivek = new Vivek();
//		vivek.eat();
//		vivek.breathe();
//		vivek.sleep();
//		Human.walk();
//		
//		SriLakhsmi sriLakhsmi = new SriLakhsmi();
//		sriLakhsmi.eat();
//		sriLakhsmi.sleep();
//		sriLakhsmi.breathe();
		
		Human []refs = new Human[4];//Is-A
		
//		refs[0] = new Human();//Not allowed
		
		refs[0] = new Vivek();
		refs[1] = new Pradeep();
		refs[2] = new Nandita();
		refs[3] = new SriLakhsmi();
		
		
//		refs[1] = new InheritanceDemo();
		
		for(Human item : refs) {
			item.eat();
			item.sleep();
			item.breathe();
			
			if(item instanceof Pradeep)
				((Pradeep)item).play();//Reference variable casting
		}
		
		
		
		
		
		

		
//		new Human();Not allowed!!!
		
		
	}
}


interface Human{
//	private int arms;
//	private String name;
//	private int heart;
	
	int ARMS = 2;
	
	void sleep();
	
	void eat(); 
	
	void breathe();
	
//	void walk();//Created after 5 months
	
//	Allowed starting Java 8:
	static void walk() {
		System.out.println("Human's new walk()...");
	}
}

interface Footballer extends Human{
	void play();
}

interface Swimmer{
	void swim();
}

class Nandita implements Swimmer, Human{

	@Override
	public void sleep() {
		System.out.println("Nandita's sleep");
		
	}

	@Override
	public void eat() {
		System.out.println("Nandita's eat");
		
	}

	@Override
	public void breathe() {
		System.out.println("Nandita's breathe");
		
	}

	@Override
	public void swim() {
		System.out.println("Nandita's swim");
		
	}
	
}

class Pradeep implements Footballer{

	@Override
	public void sleep() {
		System.out.println("Pardeep's sleep");
		
	}

	@Override
	public void eat() {
		System.out.println("Pardeep's eat");
		
	}

	@Override
	public void breathe() {
		System.out.println("Pardeep's breathe");
		
	}

	@Override
	public void play() {
		System.out.println("Pardeep's play");
		
	}
	
}

class Vivek implements Human{

	@Override
	public void sleep() {
		System.out.println("Vivek's sleep");
		
	}

	@Override
	public void eat() {
		System.out.println("Vivek's eat");
		
	}
	
	public void breathe() {
		System.out.println("Vivek's breathe");
	}

}

class SriLakhsmi implements Human{
	@Override
	public void sleep() {
		System.out.println("Srilakshmi's own way of sleeping...");
	}
	
	@Override
	public void eat() {
		System.out.println("Srilakshmi's own way of eating...");
	}
	
	void sing() {
		System.out.println("Srilakshmi can sing...");
	}

	@Override
	public void breathe() {
		System.out.println("Srilakshmi's breathe");
		
	}
	
}








