package com.tcs.waleed.development;

public class ThreadSyncDemo {
	public static void main(String[] args) {
		new Thread(new MyTask()).start();
	}
}

class MyTask implements Runnable{
	@Override
	public synchronized void run() {
		System.out.println(Thread.currentThread().getName());
		
	}
}
