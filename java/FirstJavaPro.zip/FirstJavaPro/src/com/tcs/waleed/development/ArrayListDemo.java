package com.tcs.waleed.development;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		List<String> listOfItems = new ArrayList<>();
		
		listOfItems.add("Parth");
		System.out.println(listOfItems.size());
		
		listOfItems.add("Venkatesh");
		
		listOfItems.add("Prasetha");
		listOfItems.add("Venkatesh");//Stores!!!
		
		System.out.println(listOfItems.size());
		
		listOfItems.remove(2);
		
		System.out.println(listOfItems.get(3));
		
		System.out.println(listOfItems);
		
		listOfItems.add("Prashanth");
//		listOfItems.add(1086);
		
		System.out.println(listOfItems);
		
//		for(String item: listOfItems) {
//				System.out.println(item.charAt(0));
//		}
		
		listOfItems.forEach(System.out::println);//Works starting Java 8
		
//		Integer []arr
		
		
		
	}
}
