package com.tcs.waleed.development;

public class StringDemo {
	public static void main(String[] args) {	
		String strVar = "TCS";
		System.out.println(strVar);
		
		strVar = strVar.concat(" Java FSD Training is currently ongoing. It is a good one");
		
		System.out.println(strVar);
		
		
		System.out.println("Length : " + strVar.length());
		
		System.out.println(strVar.charAt(6));
		
		strVar.toUpperCase();
		
		System.out.println(strVar);
		
//		strVar = strVar.substring(5);
		
//		strVar = strVar.substring(4, 9);
		
//		System.out.println(strVar);
		
		String []values = strVar.split("is");
		
		System.out.println("After tokenizing: ");
		for(String value : values) {
			System.out.println(value);
		}
		
		
		StringBuffer buffer = new StringBuffer("C++");
		
		//System.out.println(buffer);
		
		buffer.append(" is great as well");
	
		
		System.out.println(buffer);
		
		StringBuilder builder = new StringBuilder("Working with builders");
		
//		String st = "Pradeep";
//		
//		st = "Changed";
//		
//		StringBuffer buffert = new StringBuffer("Pradeep");
//		
//		buffert = "changed";
//		
//		StringBuilder ref = new StringBuilder("tcs");
//		ref.setCharAt(ref.indexOf("c"), 'w');
//		System.out.println(ref);
		
		
		
		
	}
}
