package com.tcs.waleed.development;

public class MethodLocalDemo {
	public static void main(String[] args) {
		new OtherClass().met();
		
		float f = 909.89f;
		
	}
}
//Inside a method local inner class ,
//only final or effectively final(java8) variables of
//the enclosing method are accessible

class OtherClass{
	void met() {
		int myVar = 908;//Effectively final until we change it
		class Inner{

			public void in() {
				System.out.println(myVar);//Error pre Java 8
				System.out.println("Inside Inner's in()...");
				
			}
			
		}
	new Inner().in();
	}
}
