package com.tcs.waleed.development;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		Map<Integer, String> map =  new TreeMap<>();
		
		map.put(23, "Shashwat");
		map.put(121, "Usman");
		map.put(3456, "Lekha");
		
		System.out.println(map);
	}
}
