package com.tcs.waleed.development;

public class ICDemo {
	
	public static void main(String[] args) {
//		Outer out = new Outer();
//		out.func();
		
//		Outer out = new Outer();
//		Outer.Inner ref = out.new Inner();
//		ref.in();
		
//		or succinctly:
			new Outer().new Inner().in();
		
		
	}

}

//ICDemo.class
//Outer.class
//Outer$Inner.class


class Outer{
	boolean status;
	class Inner{
		boolean status;
		
		void in() {
			boolean status = true;
			System.out.println("Inside Inner's in()...");
			System.out.println("Local status : " + status);
			System.out.println("Inner's instance status : " + this.status);
			System.out.println("Outer's instance status : " + Outer.this.status);
		}
	}
	
	void func() {
		Inner ref = new Inner();
		ref.in();
	}
}
