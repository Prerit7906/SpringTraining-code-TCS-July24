package com.tcs.waleed.development;

public class ThreadApply {
	public static void main(String[] args) throws InterruptedException {
		MyRunnable runnable = new MyRunnable();
		Thread thread = new Thread(runnable);
		
		thread.start();
		
		synchronized (runnable) {
			System.out.println(Thread.currentThread().getName() + " gets the lock...");	
			System.out.println(Thread.currentThread().getName() + " about to go into sleeping/waiting/suspend");	
			runnable.wait(5000);
			System.out.println(Thread.currentThread().getName() + " just got the notification, wakes up");	
		}
		
//		thread.join();
		
		System.out.println(
				"Addition of first 100 numbers : "
		+ runnable.total);
	}
}

class MyRunnable implements Runnable{
	int total;
	@Override
	public synchronized void run() {
		
		for(int value = 1; value <=100; value++) {
			total += value;
		}	
		
		//this.notify();
	}
}

//wait()
//notify()
//notifyAll()













