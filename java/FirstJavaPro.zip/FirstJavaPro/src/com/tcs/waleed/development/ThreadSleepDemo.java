package com.tcs.waleed.development;

public class ThreadSleepDemo{
	public static void main(String[] args) {
		
		Task task = new Task();
		
		Thread theThread = new Thread(task);
		
		theThread.start();
		
		
		
		
		
		
		
//		ThreadSleepDemo thread = new ThreadSleepDemo();
//		
//		thread.setName("tcs");
//		
//		thread.start();
		
//		Thread.sleep(3000);//Thread.sleep(3000);
//		System.out.println(Thread.currentThread().getName() + " just woke up...");
	}
	
}

class Task implements Runnable{

	
	@Override
	public void run(){
		System.out.println(Thread.currentThread().getName() + " about to sleep...");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println("Someone interrupted me :(");
		}
		
		System.out.println(Thread.currentThread().getName() + " just woke up...");
	}
	
//	func
//	
//	met
	
}
