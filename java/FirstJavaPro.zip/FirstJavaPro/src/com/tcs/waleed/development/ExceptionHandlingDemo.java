package com.tcs.waleed.development;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.management.RuntimeErrorException;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {
		
//		Scanner scan =  new Scanner(System.in);
//		System.out.println("Division of numbers  : " 
//		+ new Calculate().divide(scan.nextInt(), scan.nextInt()));
		
//			new ExceptionHandlingDemo().func();
		
//		System.out.println(Thread.currentThread().getName());
			
//			met();
		
	}
	
//	static void met() throws InterruptedException {
////		try {
////			if(somethingGoesReallyWrong) {
//				throw new InterruptedException();
////			}
////		met();
////		}catch (StackOverflowError e) {
////			//I can't do much here...
////		}
//	}
	
//	void func() throws NumberFormatException{
//		try {
////		IOException vulnerability here
//		}finally {
//			
//		}
		
		
		
		
	}
	
	

//class Calculate{
//	int divide(int first, int second) {
//		int result = 0;
//		try {
//		result = first / second;
//		return result;
//		//FileNotFound vulnerable code here...
//		}catch(ArithmeticException ref) {
//			//System.out.println("Sorry, division by 0 not defined yet...");
//			throw new RuntimeException("doesn't work");
//		} 
////		catch(FileNotFoundException fe) {
////			//DO something here...
////		}
//	}
//}
