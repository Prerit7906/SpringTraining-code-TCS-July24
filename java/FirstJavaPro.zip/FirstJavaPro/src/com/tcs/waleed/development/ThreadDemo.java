package com.tcs.waleed.development;

public class ThreadDemo {
	public static void main(String[] args) {
		
		Work work = new Work();
		Thread demo = new Thread(work);
		Thread second = new Thread(work);
		Thread third = new Thread(work);
		demo.setName("Pradeep");
		third.setName("Naveen");
		second.setName("Rashmi");
		demo.start();
		second.start();
		third.start();
		
//		System.out.println(Thread.currentThread().getName() + " running...2");	
	}
}

class Work implements Runnable{
	
	
	@Override
	public void run() {
		synchronized(this) {
		for(int index = 1; index <= 3; index++)
			System.out.println(Thread.currentThread().getName() + " running, index : " + index);	
	}
	}
}


//sleep(long millis);




