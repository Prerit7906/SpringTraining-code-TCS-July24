package com.tcs.waleed.development;

public class WrapperDemo {
	public static void main(String[] args) {
//		Pre Java 5:
//		Integer i = new Integer(670);
//		
//		int temp = i.intValue();//Unwrap
//		
//		temp++;//Operate
//		
//		i = new Integer(temp);//Rewrap
//		
//		System.out.println(i);
		
//		Post Java 5: Autoboxing/Unboxing
		Integer i = new Integer(542);
		i++; //
		System.out.println(i);
		int vr = 901;
		new WrapperDemo().doSomething(vr);
		
	}
	
	void doSomething(Object val) {
		//
		
		Object d = new Integer(3636);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
