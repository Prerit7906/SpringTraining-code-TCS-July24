package com.tcs.waleed.training;

public class PolymorphismDemo {
public static void main(String[] args) {
	
			new CaclulateAddition().add(102, 1110);
			new CaclulateAddition().add(102, 1110, 9);
			new CaclulateAddition().add();
	
}
}

class CaclulateAddition{
//	int add(int first, int second) {
//		return first + second;
//	}
//	int add(int first, int second, int third) {
//		return first + second + third;
//	}
//	int add(int first, int second, int third, int fourth) {
//		return first + second + third + fourth;
//	}
	
	void add(int ...values) {
		int total = 0;
		for(int value : values) {
			total += value;
		}
		System.out.println("Addition : " + total);
	}
	
	
	
}
