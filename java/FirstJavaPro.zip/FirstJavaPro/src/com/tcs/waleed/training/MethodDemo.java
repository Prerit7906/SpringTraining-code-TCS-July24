package com.tcs.waleed.training;
import java.util.Scanner;
import com.tcs.waleed.development.Other;

public class MethodDemo extends Other {
	static double item;
	public static void main(String[] args) {
		
//		I have to call Calculate's addNumbers()
//		Calculate calculate = new Calculate();
//		calculate.takeInput();
		
//		Other other = new Other();
//		other.doIt();
		
		new MethodDemo().doIt();
		
		
		
		
		new Calculate().takeInput(); //Calculate.takeInput();
		
//		MethodDemo.fun();
//		System.out.println(MethodDemo.item);

		
	}
	
	static void fun() {
		System.out.println("Inside fun...");
	}
	
//	Scope returnType indentifier(ParameterList) {
//		
//	}
	
//	 void displayMessage() {
//		 System.out.println("Displaying a message...");
//	 }	
}

class Calculate{
	
	static void takeInput() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter two numbers");
		int firstNum = scan.nextInt();
		int secondNum = scan.nextInt();
		this.displayResult(this.addNumbers(firstNum, secondNum));
		
	}
	
	private void displayResult(int result) {
		System.out.println("Addition : " + result);
		
	}

	int addNumbers(int firstNum, int secondNum) {
		
		
		return firstNum + secondNum;
		
	}
}
