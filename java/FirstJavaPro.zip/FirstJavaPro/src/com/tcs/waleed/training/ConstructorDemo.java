package com.tcs.waleed.training;

public class ConstructorDemo{

	public static void main(String[] args) {
		
		Laptop laptop = new Laptop(3838678, "h100");
		Laptop secondLaptop = new Laptop(3228875, "h200");
		Laptop thirdLaptop = new Laptop(8262, "h100");
		
		Laptop laptopForAsia = new Laptop();
		
		Laptop []laptops = new Laptop[4];
		laptops[0] = laptop;
		laptops[1] = secondLaptop;
		laptops[2] = thirdLaptop;
		laptops[3] = laptopForAsia;
		
		laptop.setRam(16);
		
		for(Laptop item : laptops) {
		System.out.println(item);
		}
		
	}
	
	
//	ConstructorDemo() {
//		System.out.println("Constructor Called...");
//	}
}
//java.lang.Object : Super class of every class in Java
class Laptop{
	private long serialNumber;
	private String model;
	private int ram;
	
	Laptop(long serialNumber, String model){
		this.serialNumber = serialNumber;
		this.model = model;
	}
	
	Laptop(){
		
	}


	public long getSerialNumber() {
		return this.serialNumber;
	}
	
	public void setSerialNumber(long serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public String getModel() {
		return this.model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public void setRam(int ram) {
		this.ram = ram;
	}
	
	public int getRam() {
		return this.ram;
	}
	
	public String toString() {
return "Laptop : Serial number : "
	+ this.serialNumber + ", model: "
	+ this.model + ", ram : "
	+ this.ram;
	}	
}

class Car{
	private long chasisNumber;
	private String model;
	
	Car(){
		
	}

	public Car(long chasisNumber, String model) {
		super();
		this.chasisNumber = chasisNumber;
		this.model = model;
	}

	public long getChasisNumber() {
		return chasisNumber;
	}

	public void setChasisNumber(long chasisNumber) {
		this.chasisNumber = chasisNumber;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	@Override
	public String toString() {
		return "Car [chasisNumber=" + chasisNumber + ", model=" + model + "]";
	}
	
	

	
	
}






//Constructor
//	- 
