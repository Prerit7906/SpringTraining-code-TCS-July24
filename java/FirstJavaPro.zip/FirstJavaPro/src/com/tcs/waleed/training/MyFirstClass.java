package com.tcs.waleed.training;
import java.util.Scanner;

import com.tcs.waleed.development.Human;

public class MyFirstClass {
	public static void main(String[] args) {
		System.out.println("Our First Java Program");
		
//		Datatype identifier;
		
		boolean vr = false, flag;
		int myIntVar = 901;
		
		System.out.println(vr);
		System.out.println("Value of int varible is  : " + myIntVar);
		
		float otherVar = 67.90f;
		
		System.out.println(otherVar);
		
		int i = (int )otherVar; //Narrowing
		
		double d = i;//double d = (double) i;
		
		System.out.println(i);
		
		
		
//		Scanner scan = new Scanner(System.in);
//		
//		System.out.println("Please enter a number");
//		
//		int num = scan.nextInt();
//		
////		boolean f = false;
//		
//		if(num == 100) {
//			System.out.println("Equal to 100");
//		}
//		else {
//			System.out.println("Not equal to 100");
//		}
		
//		&& || !
		
//		for, while, do-while
		
//		1
//		1
//		2
//		3
//		5
//		8
//		13
//		21
//		34
//		55
//		89
		
		
		
		
		
//		System.out.println("You just entered : " + num);
		
		
//		byte -  1
//		short - 2
//		boolean - 2
//		char - 2
//		int - 4
//		long - 8
//		float - 4
//		double - 8
		
		
		
		
		
		
//		Arrays
//		DataType []identifier = new DataType[dimension];
		
		
//		Class:
//		 - Human
//		 	- breathe
//		 	- eat
//		 	- sleep
//		 	- run
//		 	- smile
//		 	- cry
//		 	
//		 	- legs
//		 	- arms
//		 	- eyes
//		 	- heart
//		 	- ears
//		 	
//		 	class identifier{
//			 functions
//			 variables
//		 }
		 	
		 
//		 Type identifier = new Type();
		 
//		 Human ref = new Human();
//		 ref.legs = 2;
//		 System.out.println(ref.run());
//		 
//		 System.out.println(new Human().run());
//		 
		 	
//		 Type []identifier = new Type[Dimension];
		
		char []values = new char[10];
		values[0] = 't';
		values[6] = 'r';
//		values[11] = 'i';//AIOOBE
		
		int []arr = new int[5];
		
		arr[0] = 56;
		arr[1] = 156;
		arr[2] = 3782;
		arr[3] = 1;
		arr[4] = 199;
		
//		for(int index = 0; index < arr.length; index++) {
//			System.out.println(arr[index]);
//		}
		
//		Or with java 5 enhanced for:
		
//		for(Variable declaration : Name of Array/Collection) {
//			
//		}
		
//		for(float value : arr) {
//			System.out.println(value);
//		}
//			
		
		
		boolean []vals = {false, true, true, true, false, true};
		
		
		new MyFirstClass().doSomething(new int[]{670, 4648, 89, 900});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		Human nilesh = new Human();
//		System.out.println(nilesh.flag);
//		System.out.println(nilesh.ref);
//		
//		Human vivek = nilesh;
//		
//		nilesh.ref = nilesh;//Works
//		nilesh.legs = 2;
//		vivek.legs = 2;
//		System.out.println(nilesh.ref.legs);
		
//		System.out.println(nilesh.ref.legs);
		
		
		
		
		
		
		
	}
	
	void doSomething(int []arr) {
		
	}
}


//	int notAllowed;//Not allowed to declare here
	class Human{
		boolean flag;
		Human ref;
		int legs;
		void run() {
			float cal = 0.0f;
			System.out.println(cal);
			
			for(int index = 11; index <= 23; index++)
				System.out.println(index);
//			System.out.println(index);
			
			
			
		}
		
		void other() {
//			cal = 90.9f;//Not accessible here
//			----------Local----------
		}
		
}
	
//	Instance variable
//	byte
//	short
//	int
//	long
//	
//	char - \u0000
//	
//	float
//	double
//	
//	boolean - false
//	
//	
//	Reference Variable - null
	
	
	
	
	
	
	
	
	
	
	
	
	
	
