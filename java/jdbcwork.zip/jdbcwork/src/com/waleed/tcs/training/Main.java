package com.waleed.tcs.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

record Participant(String name, String skills) {}

public class Main {
	
	Connection dbConnect;
	
	Statement theStatement;
	
	PreparedStatement preparedStatement;
	
	String query;

	public static void main(String[] args) {
	
		new Main().dbConnect();

	}
	
	void dbConnect() {

		try {
//			Load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
//			Try establishing the connection
			dbConnect = DriverManager.getConnection("jdbc:mysql://localhost:3306/tcs_July_24", "root", "");
			
//			Get a Statement reference
			theStatement = dbConnect.createStatement();
			
//			getAllParticipants();
			
//			registerParticipant(new Participant("Sreeshant", "Java, SQL, Python"));
			
registerParticipantUsingPreparedStatement(new Participant("Lohith", "Ruby, Javascript, JQuery"));			
			
//			System.out.println("Connected to the db...");
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Some issues : " + e.getMessage());
		
			
//			Java 7 try with resources
//			try(PrintWriter file = new PrintWriter(new File("test.txt"))) {
//				
			}		
	}
	
//	Get All participants
	void getAllParticipants() {
//		Write the query
		query = "select * from participant_details";
	
		try {
//			Execute the query
			ResultSet resultSet = theStatement.executeQuery(query);
			
//			Traverse the results
			while(resultSet.next()) {
System.out.print(resultSet.getString("participantName"));
System.out.println(", skills : " + resultSet.getString("participantSkills"));
			}
			dbConnect.close();
		} catch (SQLException e) {
			System.out.println("issues while executing query : " + e.getMessage());
		}
		
//		Java 16 - Text blocks
//		String str = """
//				hello
//				how are you doing
//				NIce , works fine in the recent versions of Java
//				""";
	
		
	}
	
	void registerParticipant(Participant participant) {
	query = "insert into participant_details"
			+ "(participantName, participantSkills)"
			+ " values('" + participant.name() + "', '" + participant.skills() + "')";
	
	try {
		if(theStatement.executeUpdate(query) > 0)
			System.out.println("Participant registered...");
	} catch (SQLException e) {
		System.out.println("Issues while inserting : " + e.getMessage());
	}
	}
	
	
	
	void registerParticipantUsingPreparedStatement(Participant participant) {
query = "insert into participant_details(participantName, participantSkills)values(?,?)";
		

		
		try {
			preparedStatement = dbConnect.prepareStatement(query);
			
//			Put in the values for placeholders
			preparedStatement.setString(1, participant.name());
			preparedStatement.setString(2, participant.skills());
			
//			Execute the query	
			if(preparedStatement.executeUpdate() > 0)
				System.out.println("Participant registered...");
		} catch (SQLException e) {
			System.out.println("Issues while inserting : " + e.getMessage());
		}
		}

}
