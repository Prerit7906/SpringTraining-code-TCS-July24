package com.tcs.training;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			System.out.println("Loaded the driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
