package com.tcs.waleed.training;

//import static org.junit.jupiter.api.Assertions.fail;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@TestInstance(Lifecycle.PER_CLASS)
public class AppTest {
	
	App app;
	
	@BeforeAll
	static void callBeforeEverything() {
		System.out.println("Called at the beginning...");
	}
	
	@AfterAll
	static void callAtLast() {
		System.out.println("Called at the last...");
	}
	
	@BeforeEach
	void callBeforeEach() {
		app = new App();
		System.out.println("Called before each test");
	}
	
	@AfterEach
	void callAfterEach() {
		System.out.println("Called after each test");
	}
	
	
	
	
	
//	@Test
//	void testSample() {
//		fail("Test sample has failed...");
//	}
	
	
	@Test
	@DisplayName("check for division")
	void testDivide() {

//		assertEquals(5, new App().divide(20, 3), "Division not working as expected");
		assertNotEquals(5, new App().divide(20, 3), "Division not working as expected");
		
		
		assertNotNull(app);
		
		assertAll(
				() -> assertEquals(4,  app.divide(10, 2)),
				() -> assertNotEquals(10, app.divide(200, 10)),
				() -> assertNotEquals(10, app.divide(390, 40))
				);
	}
	
	@ParameterizedTest
	@ValueSource(strings = {"nilesh", "madam", "harsh"})
//	@EnabledOnOs(OS.WINDOWS)
//	@EnabledOnJre(JRE.JAVA_15)
//	@Disabled //Disabled test this
	@DisplayName("palindrome check")
	void testCheckForPalindrome(String value) {
		assertTrue(app.checkForPalindrome(value), "not a palindrome string");
	}
	
	
	
	
	
	
}
