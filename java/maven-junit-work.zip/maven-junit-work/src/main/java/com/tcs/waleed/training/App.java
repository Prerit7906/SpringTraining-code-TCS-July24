package com.tcs.waleed.training;


public class App 
{
    int divide(int first, int second) {
    	return first / second;
    }
    
    
    boolean checkForPalindrome(String value) {
    	if(value.equals("madam"))
    		return true;
    	else
    		return false;
    }
}
