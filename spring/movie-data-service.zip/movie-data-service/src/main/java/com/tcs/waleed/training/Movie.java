package com.tcs.waleed.training;

record Movie(String name, String genre, String description) {}
