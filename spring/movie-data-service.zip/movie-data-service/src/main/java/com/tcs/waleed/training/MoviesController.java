package com.tcs.waleed.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MoviesController {
	
	@Autowired
	MovieService service;
	
	@GetMapping("/movies")
	List<Movie> getMovies() {
		return service.getMovies();
	}

}
