package com.tcs.waleed.training;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class MovieService {

	List<Movie> getMovies() {
		return Arrays.asList(
				new Movie("Shawshank Redemption", "Thriller/Mystrey", "A Prison break Story..."),
				new Movie("Inception", "SciFi", "A Dream Recursion movie"),
				new Movie("Iron Man", "Fantasy", "Super hero who saves the world"),
				new Movie("Mirzapur", "Crime", "Crime lords ruling Mirzapur"));
	}

}
