package com.waleed.tcs.training;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component("namedParam")
public class NamedParameterJdbcTemplateDemo {
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	DataSource dataSource;
	
	
	
	 
	@Autowired
	public void setDataSource(DataSource dataSource) {
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}





	void registerParticipant(Participant participant) {
String query = "insert into participant_details(participantName, participantSkills) values(:pName, :pSkills)";

// Replace the named parameters:
		SqlParameterSource sqlParameterSource = 
				new MapSqlParameterSource("pName", participant.getParticipantName())
				.addValue("pSkills", participant.getParticipantSkills());
		
		namedParameterJdbcTemplate.update(query, sqlParameterSource);
	}
}
