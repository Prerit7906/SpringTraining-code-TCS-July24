package com.tcs.waleed.training;

public class Club {
	
	private String name;
	private String founded;
	
	public Club() {
		// TODO Auto-generated constructor stub
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFounded() {
		return founded;
	}
	public void setFounded(String founded) {
		this.founded = founded;
	}
	public Club(String name, String founded) {
		super();
		this.name = name;
		this.founded = founded;
	}
	@Override
	public String toString() {
		return "Club [name=" + name + ", founded=" + founded + "]";
	}

}
