package com.tcs.waleed.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


//@Controller
//@Service
//@Repository
@Component("aFootballer")
@PropertySource("classpath:test.properties")
public class AnnotationsFootballer implements Footballer {
	
	@Autowired
	@Qualifier("otherClub")//For the exact match
	private Club club;
	
	@Value("${test.userName}")
	private String userName;
	
	@Value("${test.location}")
	private String userLocation;
	
	public AnnotationsFootballer() {
		
	}
	
//	@Autowired
//	public AnnotationsFootballer(Club club) {
//		super();
//		this.club = club;
//	}
//
//	//@Autowired
//	public void setClub(Club club) {
//		this.club = club;
//	}

	@Override
	public void play() {
		System.out.println("Hi I am a Annotations Footballer and I play for :");
		System.out.println(club);
		
		System.out.println("And my details are :");
		System.out.println(userName + " from " + userLocation);
		
	}

}
