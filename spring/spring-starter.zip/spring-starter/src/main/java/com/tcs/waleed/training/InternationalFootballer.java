package com.tcs.waleed.training;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class InternationalFootballer implements Footballer{//, InitializingBean, DisposableBean {
	
	private Club club;
	
	public InternationalFootballer() {
		
	}

	@Override
	public String toString() {
		return "InternationalFootballer [club=" + club + "]";
	}

	public InternationalFootballer(Club club) {
		this.club = club;
	}

	public Club getClub() {
		return club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	@Override
	public void play() {
		System.out.println("Hey there I play international football, and I also play for the club:");
		System.out.println(club);

	}

//	@Override
	public void callAtEnd(){
		System.out.println("InternationalFootballer bean about to be destroyed...");
		
	}

//	@Override
	public void callAtBeginning() {
		System.out.println("InternationalFootballer bean instantiated...");
		
	}

}
