package com.tcs.waleed.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
	
//	Footballer footballer;
//	
//	App(Footballer footballer){
//		this.footballer = footballer;
//		this.footballer.play();
//	}
	
    public static void main( String[] args )
    {
//    	App app = new App(new LeagueFootballer("Kane", "Germany"));
    	
//    	The Spring way:
    	
//    	1. Load the context:
ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("annotationsConfig.xml");

// 2. Get a reference to the bean
//	Footballer footballer = context.getBean("leagueFootballer", LeagueFootballer.class);
	Footballer footballer = context.getBean("aFootballer", AnnotationsFootballer.class);
//	Footballer otherFootballer = context.getBean("internationalFootballer", InternationalFootballer.class);
	
//	System.out.println(footballer == otherFootballer);
	
//	3. Call methods on the bean
	footballer.play();
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
}
