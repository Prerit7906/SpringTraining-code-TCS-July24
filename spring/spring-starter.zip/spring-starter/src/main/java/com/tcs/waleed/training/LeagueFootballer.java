package com.tcs.waleed.training;

import java.util.List;

public class LeagueFootballer implements Footballer {
	
	private String name;
	private String country;
	
	private List<Club> clubs;
	
public LeagueFootballer(String name, String country, List<Club> clubs) {
		super();
		this.name = name;
		this.country = country;
		this.clubs = clubs;
	}



//	private Club club;
//
//	public void setClub(Club club) {
//		this.club = club;
//	}

//	public LeagueFootballer(String name, String country, Club club) {
//		//System.out.println("Constructor of LeagueFootballer called...");
//		this.name = name;
//		this.country = country;
//		this.club = club;
//	}
	

	
	@Override
public String toString() {
	return "LeagueFootballer [name=" + name + ", country=" + country + ", clubs I play for = " + clubs + "]";
}



	public void setClubs(List<Club> clubs) {
		this.clubs = clubs;
	}



	public LeagueFootballer() {
		// TODO Auto-generated constructor stub
	}
	
	

	public void setName(String name) {
		this.name = name;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	@Override
	public void play() {
		System.out.println("League footballers play around the world...");
		System.out.println("I am one such footballer, my details:");
		
		System.out.println(this);
		
	}

}
