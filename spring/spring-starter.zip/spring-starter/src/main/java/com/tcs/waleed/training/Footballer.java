package com.tcs.waleed.training;

interface Footballer {
	void play();
}
