package com.tcs.waleed.training;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RatingsService {
	
	@Autowired
	RestTemplate restTemplate;

	Movie getMovieRating() {
		return new Movie("Shawshank Redemption", "9.2");
	}
	
	List<Object> getAllMovies() {
		String urlOfOtherService = "http://localhost:8086/movies";
		
		Object[] dataReturnedObjects =  restTemplate.getForObject(urlOfOtherService, Object[].class);
	
		return Arrays.asList(dataReturnedObjects);
	
	
	}
	
	
	
	
}
