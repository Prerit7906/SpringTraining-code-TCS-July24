package com.tcs.waleed.training;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1.0")
public class UserController {

    @GetMapping("/")
    String getPublicData(){
        return "This is a publicly accessible section";
    }

    @GetMapping("/users")
    String getUserData(){
        return "Hello User, you are now logged in...";
    }

    @GetMapping("/admin")
    String getAdminData(){
        return "Hi Admin, Welcome to your dashboard...";
    }



}
