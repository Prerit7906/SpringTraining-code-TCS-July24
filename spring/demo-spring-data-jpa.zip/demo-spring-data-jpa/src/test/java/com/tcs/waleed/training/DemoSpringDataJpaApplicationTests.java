package com.tcs.waleed.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
