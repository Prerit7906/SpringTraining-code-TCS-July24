package com.tcs.waleed.training.participants;

import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ParticipantRepository extends CrudRepository<Participant, Integer> {

//       A Custom finder method: findByXXX
       List<Participant> findByName(String name);

       @Query(nativeQuery = true, value = "select * from participant where interests LIKE %:interests%")
       List<Participant> findByInterests(String interests);

//       ManyToOne
//       OneToOne
//               ManyToMany
//       ManyToAny
}
