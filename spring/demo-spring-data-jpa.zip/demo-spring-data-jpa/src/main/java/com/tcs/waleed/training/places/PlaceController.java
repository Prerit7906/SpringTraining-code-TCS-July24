package com.tcs.waleed.training.places;

import com.tcs.waleed.training.participants.Participant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/places/api/v1.0")
public class PlaceController {

    @Autowired
    PlaceService service;

//    @GetMapping("/all/id/{participantId}")
//    List<Place> getAllPlacesByParticipantId(@PathVariable Integer participantId){
//        return service.getAllPlacesByParticipantId(participantId);
//    }

    @GetMapping("/all/{id}")
    Optional<Place> getPlaceById(@PathVariable Integer id){
        return service.getPlaceById(id);
    }

//    For @ManytoOne:
//    @PostMapping("/all/{participantId}")
//    void addNewPlace(@RequestBody Place place, @PathVariable Integer participantId){
//        place.setParticipant(new Participant(participantId, "", ""));
//        service.addNewPlace(place);
//    }

//    For Join table:
    @PostMapping("/all/{participantId}")
    void addNewPlace(@RequestBody Place place, @PathVariable Integer participantId){
        List<Participant> listOfParticipants = place.getParticipants();
        listOfParticipants.add(new Participant(participantId, "", ""));
        place.setParticipants(listOfParticipants);
        service.addNewPlace(place);
    }

//    @PutMapping("/all/{placeId}/{participantId}")
//    void updatePlace(@RequestBody Place place, @PathVariable Integer participantId){
//        place.setParticipant(new Participant(participantId, "", ""));
//        service.updatePlace(place);
//    }

//    For join table:
    @PutMapping("/all/{placeId}/{participantId}")
    void updatePlace(@RequestBody Place place, @PathVariable Integer participantId){
        List<Participant> listOfParticipants = place.getParticipants();
        listOfParticipants.add(new Participant(participantId, "", ""));
        place.setParticipants(listOfParticipants);
        service.updatePlace(place);
    }
    @DeleteMapping("/all/{id}")
    void deletePlace(@PathVariable Integer id){
        service.deletePlace(id);
    }
}
