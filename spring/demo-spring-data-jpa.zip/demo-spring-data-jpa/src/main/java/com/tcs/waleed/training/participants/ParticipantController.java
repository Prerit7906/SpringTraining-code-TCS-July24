package com.tcs.waleed.training.participants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("participants/api/v1.0")
public class ParticipantController {

    @Autowired
    ParticipantService service;


    @GetMapping("/all")
    List<Participant> getAllParticipants(){
        return service.getAllParticipants();
    }

    @GetMapping("/all/{id}")
    Optional<Participant> getParticipantById(@PathVariable Integer id){
        return service.getParticipantById(id);
    }

    @GetMapping("/all/name/{name}")
    List<Participant> getParticipantsByName(@PathVariable String name){
        return service.getParticipantsByName(name);
    }

    @GetMapping("/all/interests/{interests}")
    public List<Participant> getParticipantsByInterests(@PathVariable String interests){
        return service.getParticipantsByInterests(interests);
    }

    @PostMapping("/all")
    void addNewParticipant(@RequestBody Participant participant){
        service.addNewParticipant(participant);
    }

    @PutMapping("/all/{id}")
    void updateParticipant(@RequestBody Participant participant){
       service.updateParticipant(participant);
    }

    @DeleteMapping("/all/{id}")
    void deleteParticipant(@PathVariable Integer id){
        service.deleteParticipant(id);
    }


}
