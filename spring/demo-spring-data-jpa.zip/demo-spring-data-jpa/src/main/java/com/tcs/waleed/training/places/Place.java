package com.tcs.waleed.training.places;

import com.tcs.waleed.training.participants.Participant;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Place {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer placeId;

    private String placeName;

    private String placeState;

    @ManyToMany
    @JoinTable(name = "participant_group",
    joinColumns = @JoinColumn(name = "placeId"),
            inverseJoinColumns = @JoinColumn(name = "id")
    )
    private List<Participant> participants = new ArrayList<>();

    public List<Participant> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Participant> participants) {
        this.participants = participants;
    }

    @Override
    public String toString() {
        return "Place{" +
                "placeId=" + placeId +
                ", placeName='" + placeName + '\'' +
                ", placeState='" + placeState + '\'' +
                ", participants=" + participants +
                '}';
    }

    Place(){

    }

//    @ManyToOne
//    private Participant participant; //Tie this Place to a Participant instance : Foriegn Key to Primary Key relationship

    public Place(Integer placeId, String placeName, String placeState, Integer participantId) {
        this.placeId = placeId;
        this.placeName = placeName;
        this.placeState = placeState;
//        this.participant = new Participant(participantId, "", "");
    }

    public Integer getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Integer placeId) {
        this.placeId = placeId;
    }

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public String getPlaceState() {
        return placeState;
    }

    public void setPlaceState(String placeState) {
        this.placeState = placeState;
    }

//    public Participant getParticipant() {
//        return participant;
//    }
//
//    public void setParticipant(Participant participant) {
//        this.participant = participant;
//    }


}
