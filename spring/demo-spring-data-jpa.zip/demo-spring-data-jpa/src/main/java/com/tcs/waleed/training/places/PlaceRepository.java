package com.tcs.waleed.training.places;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PlaceRepository extends CrudRepository<Place, Integer> {

//    List<Place> findByParticipantId(Integer participantId);

}
