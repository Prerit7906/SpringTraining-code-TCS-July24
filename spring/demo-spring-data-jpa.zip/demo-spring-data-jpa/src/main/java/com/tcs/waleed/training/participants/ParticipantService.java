package com.tcs.waleed.training.participants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ParticipantService {

    @Autowired
    ParticipantRepository repo;

    List<Participant> getAllParticipants(){
        return ((List)(repo.findAll()));
    }

    Optional<Participant> getParticipantById(Integer id){
        return repo.findById(id);
    }

    public List<Participant> getParticipantsByName(String name) {
        return repo.findByName(name);
    }

    public List<Participant> getParticipantsByInterests(String interests){
        return repo.findByInterests(interests);
    }

    void addNewParticipant(Participant participant){
        repo.save(participant);
    }

    void updateParticipant(Participant participant){
        repo.save(participant);
    }

    void deleteParticipant(Integer id){
        repo.deleteById(id);
//        CustomExample<String, Integer> obj = new CustomExample();
//        CustomExample<Participant, ParticipantService> obj2 = new CustomExample();
    }

}

//
//class CustomExample<T, I>{
//    T ref;
//    I another;
//
//    CustomExample(T ref){
//        this.ref = ref;
//    }
//
//    public T getRef(){
//        return this.ref;
//    }
//
//    public void setRef(T ref){
//        this.ref = ref;
//    }
//
//    String getValues(){
//        return ref.toString();
//    }
//
//
//}



