package com.tcs.waleed.training.places;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlaceService {

    @Autowired
    PlaceRepository repo;


//    List<Place> getAllPlacesByParticipantId(Integer participantId){
//        return repo.findByParticipantId(participantId);
//    }


    Optional<Place> getPlaceById(Integer id){
        return repo.findById(id);
    }

    void addNewPlace(Place place){
        repo.save(place);
    }

    void updatePlace(Place place){
        repo.save(place);
    }

    void deletePlace(Integer id){
        repo.deleteById(id);
    }

}
