package com.tcs.waleed.training;

public record Learner(Integer id, String name, String interests) {

}
