package com.tcs.waleed.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LearnerController {

	List<Learner> learners = new ArrayList<>(
			Arrays.asList(
					new Learner(12, "Ramanouj", "Web App Dev, Mobile"),
					new Learner(13, "Shreyas", "UI, Devops"),
					new Learner(131, "Usman", "Backend, Devops"),
					new Learner(231, "Rashmi", "UI, Devops, Cloud")
					)
			);
	
//	Get all learners
	@GetMapping("/learners")
	List<Learner> getAllLearners() {
		return learners;
	}
	
//	Get a Learner by ID
	@GetMapping("/learners/{id}")
	Learner getLearnerById(@PathVariable Integer id) {
		return learners.stream().filter(ref -> ref.id().equals(id)).findFirst().get();
	}
	
	
//	Add a new Learner
//	@RequestMapping(value = "/learners", method = RequestMethod.POST)
	
	@PostMapping("/learners")
	void addNewLearner(@RequestBody Learner learner) {
		learners.add(learner);
	}
	
	
//	Update a Learner
	@PutMapping("/learners/{id}")
	void updateLearner(@PathVariable Integer id, @RequestBody Learner learner) {
		learners.set(
				learners.indexOf(
						learners.stream().filter(ref -> ref.id().equals(id)).findFirst().get()), learner);
	}
	
//	Delete a Learner
	@DeleteMapping("/learners/{id}")
	void deleteLearner(@PathVariable Integer id) {
		learners.remove(
				learners.indexOf(
						learners.stream().filter(ref -> ref.id().equals(id)).findFirst().get()));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
