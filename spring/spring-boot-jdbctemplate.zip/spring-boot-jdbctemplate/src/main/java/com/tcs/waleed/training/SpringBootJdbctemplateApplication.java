package com.tcs.waleed.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbctemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJdbctemplateApplication.class, args);
	}

}
