package com.tcs.waleed.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@GetMapping("/count")
	Integer getCountOfUsers() {
		return jdbcTemplate.queryForObject("select count(*) from participant_details", Integer.class);
	}
	
}
